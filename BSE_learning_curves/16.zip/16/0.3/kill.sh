#!/bin/bash
mkdir onemore
mv -f ./A2-A2-CNOT_HWE-CZ onemore/
mv -f ./A2-A2-CZ_HWE-CZ  onemore/
mv -f ./M-A2-CZ_HWE-CNOT onemore/
mv -f ./M-A2-CZ_HWE-CZ onemore/
mv -f ./M-M-CNOT_HWE-CNOT onemore/
mv -f ./M-M-CNOT_HWE-CZ onemore/
mv -f ./M-M-CZ_Hadamard onemore/
