#!/bin/bash
python3 main.py --settings IQP_Full-Pauli-CRX/IQP_Full-Pauli-CRX.json --train_set 5_DDCC_train.bin --test_set 5_DDCC_test.bin --scaler 5_DDCC_scaler.bin --save_path ./ --save_circuits True 
