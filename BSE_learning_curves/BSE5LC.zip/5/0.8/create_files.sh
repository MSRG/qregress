#!/bin/bash
python3 settings.py --optimizer SPSA --num_qubits 5 --tol 1e-5 --batch_size 25 --njobs 16
