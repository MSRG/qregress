rm */*.svg
rm */*model_log.csv
rm */*_state_model.bin
rm */*_predicted_values.csv
rm */*_results.json
rm */*.out
