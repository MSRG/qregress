sbatch A1_HWE-CNOT.sub
sbatch A2_HWE-CNOT.sub
sbatch M-A1-CZ_HWE-CNOT.sub
sbatch M_HWE-CNOT.sub
sbatch M-M-CNOT_HWE-CZ.sub
