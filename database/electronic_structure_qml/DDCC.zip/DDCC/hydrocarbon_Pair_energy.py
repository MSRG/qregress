#!/usr/bin/env python
# coding: utf-8

# In[1]:


import sys
from helper_ML_pairtools import GetPairEnergies, GenerateFeatures,pair_energy, CompareLocalization
import os
import time
from helper_CC_ML_spacial import *
from helper_ML_tools import SplitFolder

from sklearn.metrics import *
import matplotlib.pyplot as plt
import psi4


# In[ ]:


# User defined example name
Calc_name='example_name'

# Path to the xyz coordinates with subfiles for train and test data
Folder='xyz_str/'

# Run using Pipek-Mezey localization and the STO-3G basis set considering only 10 of the excitations for each pair-energy
ML=pair_energy(Folder+'train/',test_folder=Folder+'test/', loc_occ='PM', loc_vir='PM', Triples=False, basis='STO-3G', values=10)# cutoff=1e-5,)



# In[ ]:


# Run the machine learning 
ML.test_folder=Folder+'test/'

ML.calculate_train()

ML.train_model()

a,b,c,d=ML.test()


# In[ ]:


plt.scatter(df['True Energy'],df['Predicted Energy'])
plt.title(r'R$^{2}$'+f"={r2_score(df['True Energy'],df['Predicted Energy']):.4f}")
plt.xlabel(r'True Correlation Energy (E$_{h}$)')
plt.ylabel(r'Predicted Correlation Energy (E$_{h}$)')
plt.show()


# In[ ]:




